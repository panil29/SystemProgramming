// I have choosen the source directory as "C:\cygwin64\home\hp\anil\library"
//In the source directory ("C:\cygwin64\home\hp\anil\library")create two files named "MyLibrary.h" and "main.c" add the code given below
//use the commands given in the ouput to chage the directiory,compile the two files,and excute.
#include "MyLibrary.h"
int main(){
//this will print hello
Hello();
//this will print world
World();
//this will print nothing (last printed value != "Hello")
World();
//This will print hello
Hello();
//this will print nothing (last printed value != "world")
Hello();
//this will print world (last printed value != "Hello")
World();
//this will print nothing
World();
//this will print hello
Hello();
//this will print world
World();
}
