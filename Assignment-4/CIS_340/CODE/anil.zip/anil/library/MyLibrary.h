// I have choosen the source directory as "C:\cygwin64\home\hp\anil\library"
//In the source directory ("C:\cygwin64\home\hp\anil\library")create two files named "MyLibrary.h" and "main.c" add the code given below
//use the commands given in the ouput to chage the directiory,compile the two files,and excute.

#include<stdio.h>
//CREATE A STATIC VARIBLE
static int ag=0;
int Hello(){
//TO ENSURE Hello is prined rst
if(ag==0){
printf("\n Hello ");
//Flag to print World after Hello
ag=1;
return 1;
}
return 0;
}
int World()
{
//to ensure world is printed after the hello
if(ag==1){
printf(" World");
//Flag to print Hello after World
ag=0;
return 1;
}
return 0;
}
